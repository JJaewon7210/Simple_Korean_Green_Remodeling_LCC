export const PPI = [
    {
        year: 2013,
        value: 104.74,
    },
    {
        year: 2014,
        value: 104.18,
    },
    {
        year: 2015,
        value: 100.00,
    },
    {
        year: 2016,
        value: 98.18,
    },
    {
        year: 2017,
        value: 101.57,
    },
    {
        year: 2018,
        value: 103.48,
    },
    {
        year: 2019,
        value: 103.50,
    },
    {
        year: 2020,
        value: 103.03,
    },
    {
        year: 2021,
        value: 109.60,
    },
    {
        year: 2022,
        value: 118.78,
    },
    {
        year: 2023,
        value: 120.58,
    },
];